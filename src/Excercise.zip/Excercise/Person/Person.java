package Excercise.Person;

public interface Person {
    String getName();

    int getAge();
}

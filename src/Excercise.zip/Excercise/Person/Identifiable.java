package Excercise.Person;

public interface Identifiable {
    String getId();
}

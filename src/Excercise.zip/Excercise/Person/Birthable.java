package Excercise.Person;

public interface Birthable {
    String getBirthDate();
}
